import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

st.set_page_config(
    page_title="Experiment 7: KMeans Clustering",
    layout="wide"
)

st.title("Experiment 7")
st.subheader("Implement K-Means Clustering Algorithm")

st.divider()

# ---------------------------------------------------
# Upload Dataset
# ---------------------------------------------------

uploaded_file = st.file_uploader(
    "Upload Telecom Tower Dataset (.csv)",
    type="csv"
)

if uploaded_file is None:
    st.info("Upload a CSV file to begin.")
    st.stop()

df = pd.read_csv(uploaded_file)

st.success("Dataset Loaded Successfully")

st.divider()

# ---------------------------------------------------
# Dataset Information
# ---------------------------------------------------

c1,c2,c3 = st.columns(3)

with c1:
    st.metric("Rows",df.shape[0])

with c2:
    st.metric("Columns",df.shape[1])

with c3:
    st.metric(
        "Missing Values",
        int(df.isna().sum().sum())
    )

st.divider()

st.subheader("Dataset Preview")

st.dataframe(df.head())

st.divider()

st.subheader("Available Features")

st.write(df.columns.tolist())

st.divider()

# ===================================================
# STEP 1
# ===================================================

st.header("Step 1 : Select Engineering Features")

numeric_columns = df.select_dtypes(
    include=np.number
).columns.tolist()

remove_columns=[]

for col in [
    "Failure",
    "Cluster",
    "Tower_ID"
]:
    if col in numeric_columns:
        remove_columns.append(col)

numeric_columns=[
    c for c in numeric_columns
    if c not in remove_columns
]

selected_features=st.multiselect(

    "Select Features",

    numeric_columns,

    default=numeric_columns

)

if len(selected_features)==0:

    st.warning("Please select at least one feature.")

    st.stop()

if st.button(
    "Run Step 1"
):

    X=df[selected_features]

    st.success("Features Selected")

    st.write("Selected Features")

    st.write(selected_features)

    st.subheader("Selected Dataset")

    st.dataframe(X.head())

st.divider()

# ===================================================
# STEP 2
# ===================================================

st.header("Step 2 : Standardize Features")

if st.button(
    "Run Step 2"
):

    X=df[selected_features]

    scaler=StandardScaler()

    X_scaled=scaler.fit_transform(X)

    st.session_state["X_scaled"]=X_scaled

    st.session_state["scaler"]=scaler

    st.success("Standardization Completed")

    st.write("Shape")

    st.write(X_scaled.shape)

    st.subheader("Scaled Data")

    st.dataframe(
        pd.DataFrame(
            X_scaled,
            columns=selected_features
        ).head()
    )

st.divider()

# ===================================================
# STEP 3
# Elbow Method
# ===================================================

st.header("Step 3 : Determine Optimal Number of Clusters (Elbow Method)")

if "X_scaled" not in st.session_state:

    st.info("Please complete Step 2 first.")

else:

    if st.button("Run Step 3"):

        X_scaled = st.session_state["X_scaled"]

        wcss = []

        for k in range(1, 11):

            model = KMeans(
                n_clusters=k,
                random_state=42,
                n_init=10
            )

            model.fit(X_scaled)

            wcss.append(model.inertia_)

        st.session_state["wcss"] = wcss

        st.success("WCSS Calculated Successfully")

        result = pd.DataFrame({

            "K": list(range(1,11)),
            "WCSS": wcss

        })

        st.subheader("WCSS Values")

        st.dataframe(result)

        fig, ax = plt.subplots(figsize=(8,5))

        ax.plot(
            range(1,11),
            wcss,
            marker="o"
        )

        ax.set_title("Elbow Method")

        ax.set_xlabel("Number of Clusters (K)")

        ax.set_ylabel("WCSS")

        ax.grid(True)

        st.pyplot(fig)

st.divider()

# ===================================================
# STEP 4
# Select K
# ===================================================

st.header("Step 4 : Select Number of Clusters")

k = st.slider(

    "Choose Optimal K",

    min_value=2,

    max_value=10,

    value=3

)

st.session_state["k"] = k

st.write("Selected K :", k)

st.divider()

# ===================================================
# STEP 5
# Train KMeans
# ===================================================

st.header("Step 5 : Train K-Means Model")

if "X_scaled" not in st.session_state:

    st.info("Please complete Step 2.")

else:

    if st.button("Run Step 5"):

        X_scaled = st.session_state["X_scaled"]

        kmeans = KMeans(

            n_clusters=st.session_state["k"],

            random_state=42,

            n_init=10

        )

        kmeans.fit(X_scaled)

        st.session_state["kmeans"] = kmeans

        st.success("Model Trained Successfully")

        st.subheader("Cluster Labels")

        st.write(kmeans.labels_)

        df_cluster = df.copy()

        df_cluster["Cluster"] = kmeans.labels_

        st.session_state["cluster_df"] = df_cluster

        st.subheader("Dataset with Cluster Labels")

        st.dataframe(df_cluster.head())

        st.subheader("Cluster Counts")

        st.dataframe(

            df_cluster["Cluster"]

            .value_counts()

            .sort_index()

            .rename("Count")

        )

st.divider()


# ===================================================
# STEP 6
# PCA Visualization
# ===================================================

st.header("Step 6 : Visualize Clusters using PCA")

if "kmeans" not in st.session_state:

    st.info("Please complete Step 5.")

else:

    if st.button("Run Step 6"):

        X_scaled = st.session_state["X_scaled"]
        kmeans = st.session_state["kmeans"]
        df_cluster = st.session_state["cluster_df"]

        pca = PCA(n_components=2)

        X_pca = pca.fit_transform(X_scaled)

        st.session_state["X_pca"] = X_pca

        fig, ax = plt.subplots(figsize=(8,6))

        scatter = ax.scatter(
            X_pca[:,0],
            X_pca[:,1],
            c=df_cluster["Cluster"],
            cmap="viridis",
            s=60
        )

        ax.set_title("Telecom Tower Clusters")

        ax.set_xlabel("Principal Component 1")

        ax.set_ylabel("Principal Component 2")

        plt.colorbar(scatter,label="Cluster")

        st.pyplot(fig)

st.divider()

# ===================================================
# STEP 7
# Cluster Centroids
# ===================================================

st.header("Step 7 : Display Cluster Centroids")

if "kmeans" not in st.session_state:

    st.info("Please complete Step 5.")

else:

    if st.button("Run Step 7"):

        scaler = st.session_state["scaler"]

        kmeans = st.session_state["kmeans"]

        centroids = pd.DataFrame(

            scaler.inverse_transform(
                kmeans.cluster_centers_
            ),

            columns=selected_features

        )

        st.subheader("Cluster Centroids")

        st.dataframe(
            centroids.round(2)
        )

st.divider()

# ===================================================
# STEP 8
# Cluster Summary
# ===================================================

st.header("Step 8 : Cluster Summary")

if "cluster_df" not in st.session_state:

    st.info("Please complete Step 5.")

else:

    if st.button("Run Step 8"):

        df_cluster = st.session_state["cluster_df"]

        summary = (

            df_cluster

            .groupby("Cluster")[selected_features]

            .mean()

            .round(2)

        )

        st.subheader("Average Feature Values")

        st.dataframe(summary)

        st.session_state["summary"] = summary

st.divider()

# ===================================================
# STEP 9
# Silhouette Score
# ===================================================

st.header("Step 9 : Evaluate Clustering")

if "kmeans" not in st.session_state:

    st.info("Please complete Step 5.")

else:

    if st.button("Run Step 9"):

        X_scaled = st.session_state["X_scaled"]

        kmeans = st.session_state["kmeans"]

        score = silhouette_score(

            X_scaled,

            kmeans.labels_

        )

        st.metric(

            "Silhouette Score",

            round(score,4)

        )

        if score > 0.70:

            st.success("Excellent Clustering")

        elif score >= 0.50:

            st.success("Good Clustering")

        elif score >= 0.25:

            st.warning("Moderate Clustering")

        else:

            st.error("Weak Clustering")

st.divider()

# ===================================================
# FINAL RESULTS
# ===================================================

st.header("Final Results")

if "cluster_df" in st.session_state:

    st.success("Experiment Completed Successfully")

    st.write("Selected Features")

    st.write(selected_features)

    st.write("Number of Clusters")

    st.write(st.session_state["k"])

    st.write("Number of Records")

    st.write(len(st.session_state["cluster_df"]))

    st.write("Cluster Distribution")

    st.bar_chart(

        st.session_state["cluster_df"]

        .Cluster

        .value_counts()

        .sort_index()

    )

    if "summary" in st.session_state:

        st.subheader("Cluster Summary")

        st.dataframe(

            st.session_state["summary"]

        )


