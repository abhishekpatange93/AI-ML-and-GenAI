import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

st.set_page_config(
    page_title="Experiment 5 - Linear Regression",
    layout="wide"
)

st.title("Experiment 5")
st.subheader("Linear Regression for Prediction")

st.divider()

# ----------------------------------------------------
# Upload Dataset
# ----------------------------------------------------

uploaded_file = st.file_uploader(
    "Upload Telecom Tower Dataset (.csv)",
    type="csv"
)

if uploaded_file is None:
    st.info("Please upload a CSV dataset.")
    st.stop()

df = pd.read_csv(uploaded_file)

# Fill missing numeric values

num_cols = df.select_dtypes(include=np.number).columns

df[num_cols] = df[num_cols].fillna(
    df[num_cols].mean()
)

st.success("Dataset Loaded Successfully")

st.divider()

# ----------------------------------------------------
# Dataset Information
# ----------------------------------------------------

c1,c2,c3 = st.columns(3)

with c1:
    st.metric(
        "Rows",
        df.shape[0]
    )

with c2:
    st.metric(
        "Columns",
        df.shape[1]
    )

with c3:
    st.metric(
        "Missing Values",
        int(df.isna().sum().sum())
    )

st.divider()

st.subheader("Dataset Preview")

st.dataframe(df.head())

st.divider()

st.subheader("Data Types")

st.dataframe(
    df.dtypes.astype(str)
)

st.divider()

st.subheader("Summary Statistics")

st.dataframe(
    df.describe()
)


# =====================================================
# STEP 1
# Select Predictor & Target Variables
# =====================================================

st.header("Step 1 : Select Predictor and Target Variables")

numeric_columns = df.select_dtypes(
    include=np.number
).columns.tolist()

default_target = "Equipment_Temperature"

target = st.selectbox(

    "Select Target Variable",

    numeric_columns,

    index=numeric_columns.index(default_target)
    if default_target in numeric_columns
    else 0

)

default_features = [

    c for c in numeric_columns

    if c != target

]

selected_features = st.multiselect(

    "Select Predictor Variables",

    numeric_columns,

    default=default_features

)

if len(selected_features) == 0:

    st.warning("Select at least one predictor variable.")

    st.stop()

if st.button("Run Step 1"):

    X = df[selected_features]

    y = df[target]

    st.session_state["X"] = X

    st.session_state["y"] = y

    st.success("Variables Selected Successfully")

    c1, c2 = st.columns(2)

    with c1:

        st.metric(
            "Number of Predictors",
            len(selected_features)
        )

    with c2:

        st.metric(
            "Target Variable",
            target
        )

    st.subheader("Predictor Variables")

    st.write(selected_features)

    st.subheader("Feature Matrix")

    st.dataframe(X.head())

    st.subheader("Target Variable")

    st.dataframe(y.head())

st.divider()

# =====================================================
# Correlation Matrix
# =====================================================

st.subheader("Correlation Matrix")

corr = df[selected_features + [target]].corr()

st.dataframe(
    corr.round(3)
)

fig, ax = plt.subplots(figsize=(8,6))

im = ax.imshow(
    corr,
    cmap="coolwarm",
    aspect="auto"
)

plt.colorbar(im)

ax.set_xticks(
    np.arange(len(corr.columns))
)

ax.set_xticklabels(
    corr.columns,
    rotation=45,
    ha="right"
)

ax.set_yticks(
    np.arange(len(corr.columns))
)

ax.set_yticklabels(
    corr.columns
)

for i in range(len(corr.columns)):
    for j in range(len(corr.columns)):

        ax.text(
            j,
            i,
            round(corr.iloc[i,j],2),
            ha="center",
            va="center",
            fontsize=8
        )

ax.set_title("Feature Correlation Heatmap")

st.pyplot(fig)

st.divider()

# =====================================================
# Correlation with Target
# =====================================================

st.subheader("Correlation with Target Variable")

target_corr = (

    corr[target]

    .drop(target)

    .sort_values(
        ascending=False
    )

)

corr_df = pd.DataFrame({

    "Feature": target_corr.index,

    "Correlation": target_corr.values

})

st.dataframe(corr_df)

fig, ax = plt.subplots(figsize=(8,4))

ax.bar(

    corr_df["Feature"],

    corr_df["Correlation"]

)

ax.set_ylabel("Correlation")

ax.set_title("Predictor Correlation with Target")

plt.xticks(rotation=30)

st.pyplot(fig)

st.divider()


# =====================================================
# STEP 2
# Prepare Data
# =====================================================

st.header("Step 2 : Prepare Data for Linear Regression")

test_size = st.slider(

    "Testing Dataset (%)",

    min_value=10,

    max_value=40,

    value=20,

    step=5

)

if "X" not in st.session_state:

    st.info("Please complete Step 1.")

else:

    if st.button("Run Step 2"):

        X = st.session_state["X"]

        y = st.session_state["y"]

        X_train, X_test, y_train, y_test = train_test_split(

            X,

            y,

            test_size=test_size/100,

            random_state=42

        )

        st.session_state["X_train"] = X_train
        st.session_state["X_test"] = X_test
        st.session_state["y_train"] = y_train
        st.session_state["y_test"] = y_test

        st.success("Dataset Prepared Successfully")

        c1, c2, c3 = st.columns(3)

        with c1:

            st.metric(
                "Features",
                X.shape[1]
            )

        with c2:

            st.metric(
                "Training Samples",
                X_train.shape[0]
            )

        with c3:

            st.metric(
                "Testing Samples",
                X_test.shape[0]
            )

        st.subheader("Training Dataset")

        st.dataframe(
            X_train.head()
        )

        st.subheader("Testing Dataset")

        st.dataframe(
            X_test.head()

        )

st.divider()

# =====================================================
# Train/Test Distribution
# =====================================================

if "X_train" in st.session_state:

    st.subheader("Training vs Testing Distribution")

    fig, ax = plt.subplots(figsize=(5,5))

    ax.pie(

        [

            len(st.session_state["X_train"]),

            len(st.session_state["X_test"])

        ],

        labels=[

            "Training",

            "Testing"

        ],

        autopct="%1.1f%%",

        startangle=90

    )

    ax.set_title("Dataset Split")

    st.pyplot(fig)

st.divider()

# =====================================================
# Target Distribution
# =====================================================

if "y" in st.session_state:

    st.subheader("Target Variable Distribution")

    fig, ax = plt.subplots(figsize=(7,4))

    ax.hist(

        st.session_state["y"],

        bins=15

    )

    ax.set_xlabel(target)

    ax.set_ylabel("Frequency")

    ax.set_title("Target Variable Distribution")

    st.pyplot(fig)

st.divider()

# =====================================================
# Predictor Variable Distribution
# =====================================================

st.subheader("Predictor Variable Distribution")

feature = st.selectbox(

    "Select Feature",

    selected_features,

    key="feature_dist"

)

fig, ax = plt.subplots(figsize=(7,4))

ax.hist(

    df[feature],

    bins=15

)

ax.set_xlabel(feature)

ax.set_ylabel("Frequency")

ax.set_title(feature)

st.pyplot(fig)

st.divider()


# =====================================================
# STEP 3
# Train Linear Regression Model
# =====================================================

st.header("Step 3 : Train Linear Regression Model")

if "X_train" not in st.session_state:

    st.info("Please complete Step 2.")

else:

    if st.button("Run Step 3"):

        model = LinearRegression()

        model.fit(

            st.session_state["X_train"],

            st.session_state["y_train"]

        )

        st.session_state["model"] = model

        st.success("Linear Regression Model Trained Successfully")

        c1,c2 = st.columns(2)

        with c1:

            st.metric(
                "Predictor Variables",
                len(selected_features)
            )

        with c2:

            st.metric(
                "Intercept",
                round(model.intercept_,3)
            )

        coef_df = pd.DataFrame({

            "Feature":selected_features,

            "Coefficient":model.coef_

        })

        coef_df["Absolute"] = coef_df["Coefficient"].abs()

        coef_df = coef_df.sort_values(

            "Absolute",

            ascending=False

        )

        st.session_state["coef_df"] = coef_df

        st.subheader("Regression Coefficients")

        st.dataframe(coef_df)

st.divider()

# =====================================================
# Regression Equation
# =====================================================

if "model" in st.session_state:

    st.subheader("Regression Equation")

    model = st.session_state["model"]

    equation = f"{target} = {model.intercept_:.3f}"

    for feature,coef in zip(

        selected_features,

        model.coef_

    ):

        if coef >= 0:

            equation += f" + ({coef:.3f} × {feature})"

        else:

            equation += f" - ({abs(coef):.3f} × {feature})"

    st.code(equation)

st.divider()

# =====================================================
# Feature Importance
# =====================================================

if "coef_df" in st.session_state:

    st.subheader("Feature Importance")

    coef_df = st.session_state["coef_df"]

    fig,ax = plt.subplots(figsize=(9,5))

    ax.barh(

        coef_df["Feature"],

        coef_df["Coefficient"]

    )

    ax.set_xlabel("Regression Coefficient")

    ax.set_title("Engineering Feature Importance")

    st.pyplot(fig)

st.divider()

# =====================================================
# Positive vs Negative Coefficients
# =====================================================

if "coef_df" in st.session_state:

    st.subheader("Coefficient Distribution")

    positive = (

        coef_df["Coefficient"]>0

    ).sum()

    negative = (

        coef_df["Coefficient"]<0

    ).sum()

    fig,ax = plt.subplots(figsize=(5,5))

    ax.pie(

        [positive,negative],

        labels=["Positive","Negative"],

        autopct="%1.1f%%",

        startangle=90

    )

    ax.set_title("Positive vs Negative Coefficients")

    st.pyplot(fig)

st.divider()

# =====================================================
# Top Influential Features
# =====================================================

if "coef_df" in st.session_state:

    st.subheader("Most Influential Engineering Parameters")

    c1,c2 = st.columns(2)

    with c1:

        st.success(

            f"Highest Influence : {coef_df.iloc[0]['Feature']}"

        )

    with c2:

        st.info(

            f"Least Influence : {coef_df.iloc[-1]['Feature']}"

        )


# =====================================================
# STEP 4
# Predict Equipment Temperature
# =====================================================

st.header("Step 4 : Predict Equipment Temperature")

if "model" not in st.session_state:

    st.info("Please complete Step 3.")

else:

    if st.button("Run Step 4"):

        model = st.session_state["model"]

        y_test = st.session_state["y_test"]

        X_test = st.session_state["X_test"]

        predictions = model.predict(X_test)

        st.session_state["predictions"] = predictions

        comparison = pd.DataFrame({

            "Actual": y_test.values,

            "Predicted": predictions,

            "Residual": y_test.values - predictions

        })

        st.session_state["comparison"] = comparison

        st.success("Prediction Completed Successfully")

        st.subheader("Actual vs Predicted")

        st.dataframe(
            comparison.round(3)
        )

st.divider()

# =====================================================
# Actual vs Predicted Scatter Plot
# =====================================================

if "comparison" in st.session_state:

    st.subheader("Actual vs Predicted Scatter Plot")

    comparison = st.session_state["comparison"]

    fig, ax = plt.subplots(figsize=(6,6))

    ax.scatter(

        comparison["Actual"],

        comparison["Predicted"],

        s=60

    )

    min_val = comparison["Actual"].min()
    max_val = comparison["Actual"].max()

    ax.plot(

        [min_val,max_val],

        [min_val,max_val],

        "r--",

        linewidth=2

    )

    ax.set_xlabel("Actual")

    ax.set_ylabel("Predicted")

    ax.set_title("Actual vs Predicted")

    st.pyplot(fig)

st.divider()

# =====================================================
# Residual Plot
# =====================================================

if "comparison" in st.session_state:

    st.subheader("Residual Plot")

    comparison = st.session_state["comparison"]

    fig, ax = plt.subplots(figsize=(7,4))

    ax.scatter(

        comparison["Predicted"],

        comparison["Residual"],

        s=60

    )

    ax.axhline(

        y=0,

        color="red",

        linestyle="--"

    )

    ax.set_xlabel("Predicted")

    ax.set_ylabel("Residual")

    ax.set_title("Residual Plot")

    st.pyplot(fig)

st.divider()

# =====================================================
# Prediction Error Distribution
# =====================================================

if "comparison" in st.session_state:

    st.subheader("Prediction Error Distribution")

    fig, ax = plt.subplots(figsize=(7,4))

    ax.hist(

        st.session_state["comparison"]["Residual"],

        bins=15

    )

    ax.set_xlabel("Prediction Error")

    ax.set_ylabel("Frequency")

    ax.set_title("Residual Distribution")

    st.pyplot(fig)

st.divider()

# =====================================================
# Prediction Error Statistics
# =====================================================

if "comparison" in st.session_state:

    residual = st.session_state["comparison"]["Residual"]

    c1,c2,c3 = st.columns(3)

    with c1:

        st.metric(

            "Maximum Error",

            round(residual.max(),2)

        )

    with c2:

        st.metric(

            "Minimum Error",

            round(residual.min(),2)

        )

    with c3:

        st.metric(

            "Average Error",

            round(residual.mean(),2)

        )

st.divider()

# =====================================================
# Predict New Telecom Tower
# =====================================================

st.header("Predict Temperature for New Telecom Tower")

new_values=[]

cols = st.columns(2)

for i,feature in enumerate(selected_features):

    with cols[i%2]:

        value = st.number_input(

            feature,

            value=float(df[feature].mean())

        )

    new_values.append(value)

if "model" in st.session_state:

    if st.button("Predict New Tower"):

        model = st.session_state["model"]

        prediction = model.predict([new_values])[0]

        st.metric(

            "Predicted Equipment Temperature",

            f"{prediction:.2f} °C"

        )

        if prediction < 40:

            st.success("🟢 Normal Operation")

        elif prediction < 55:

            st.warning("🟡 Monitor Equipment")

        else:

            st.error("🔴 Maintenance Required")


# =====================================================
# STEP 5
# Evaluate Linear Regression Model
# =====================================================

st.header("Step 5 : Evaluate Regression Model")

if "predictions" not in st.session_state:

    st.info("Please complete Step 4.")

else:

    if st.button("Run Step 5"):

        y_test = st.session_state["y_test"]

        predictions = st.session_state["predictions"]

        mae = mean_absolute_error(
            y_test,
            predictions
        )

        mse = mean_squared_error(
            y_test,
            predictions
        )

        rmse = np.sqrt(mse)

        r2 = r2_score(
            y_test,
            predictions
        )

        st.session_state["mae"] = mae
        st.session_state["mse"] = mse
        st.session_state["rmse"] = rmse
        st.session_state["r2"] = r2

        c1,c2,c3,c4 = st.columns(4)

        with c1:
            st.metric(
                "MAE",
                round(mae,3)
            )

        with c2:
            st.metric(
                "MSE",
                round(mse,3)
            )

        with c3:
            st.metric(
                "RMSE",
                round(rmse,3)
            )

        with c4:
            st.metric(
                "R² Score",
                round(r2,4)
            )

st.divider()

# =====================================================
# Evaluation Summary
# =====================================================

if "r2" in st.session_state:

    st.subheader("Model Performance")

    r2 = st.session_state["r2"]

    if r2 >= 0.90:

        st.success("Excellent Prediction Model")

    elif r2 >= 0.75:

        st.success("Good Prediction Model")

    elif r2 >= 0.60:

        st.warning("Acceptable Prediction Model")

    else:

        st.error("Poor Prediction Model")

st.divider()

# =====================================================
# Performance Dashboard
# =====================================================

if "r2" in st.session_state:

    metrics = pd.DataFrame({

        "Metric":[

            "MAE",

            "MSE",

            "RMSE",

            "R²"

        ],

        "Value":[

            st.session_state["mae"],

            st.session_state["mse"],

            st.session_state["rmse"],

            st.session_state["r2"]

        ]

    })

    st.subheader("Performance Metrics")

    st.dataframe(metrics)

    fig,ax = plt.subplots(figsize=(8,4))

    ax.bar(

        metrics["Metric"],

        metrics["Value"]

    )

    ax.set_title("Regression Metrics")

    st.pyplot(fig)

st.divider()

# =====================================================
# Best and Worst Predictions
# =====================================================

if "comparison" in st.session_state:

    comparison = st.session_state["comparison"].copy()

    comparison["Absolute Error"] = (

        comparison["Residual"]

        .abs()

    )

    st.subheader("Top 10 Best Predictions")

    st.dataframe(

        comparison

        .sort_values(

            "Absolute Error"

        )

        .head(10)

    )

    st.subheader("Top 10 Worst Predictions")

    st.dataframe(

        comparison

        .sort_values(

            "Absolute Error",

            ascending=False

        )

        .head(10)

    )

st.divider()

# =====================================================
# Download Results
# =====================================================

if "comparison" in st.session_state:

    csv = st.session_state["comparison"].to_csv(

        index=False

    )

    st.download_button(

        "Download Prediction Results",

        csv,

        "prediction_results.csv",

        "text/csv"

    )

st.divider()

# =====================================================
# FINAL RESULTS
# =====================================================

st.header("Final Results")

if "r2" in st.session_state:

    st.success("Experiment Completed Successfully")

    c1,c2,c3 = st.columns(3)

    with c1:

        st.metric(

            "Predictor Variables",

            len(selected_features)

        )

    with c2:

        st.metric(

            "Testing Samples",

            len(st.session_state["y_test"])

        )

    with c3:

        st.metric(

            "R² Score",

            round(st.session_state["r2"],4)

        )

    st.subheader("Regression Equation")

    st.code(equation)

    st.subheader("Prediction Sample")

    st.dataframe(

        st.session_state["comparison"].head(10)

    )

    st.balloons()