import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import KFold, cross_val_score, cross_val_predict
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report
)

st.set_page_config(
    page_title="Experiment 6 - Classification",
    layout="wide"
)

st.title("Experiment 6")
st.subheader("Develop Classification Models using Logistic Regression")

st.divider()

# ----------------------------------------------------
# Upload Dataset
# ----------------------------------------------------

uploaded_file = st.file_uploader(
    "Upload Telecom Tower Dataset (.csv)",
    type="csv"
)

if uploaded_file is None:
    st.info("Upload a CSV file to begin.")
    st.stop()

df = pd.read_csv(uploaded_file)

st.success("Dataset Loaded Successfully")

st.divider()

# ----------------------------------------------------
# Dataset Information
# ----------------------------------------------------

c1, c2, c3 = st.columns(3)

with c1:
    st.metric("Rows", df.shape[0])

with c2:
    st.metric("Columns", df.shape[1])

with c3:
    st.metric(
        "Missing Values",
        int(df.isna().sum().sum())
    )

st.divider()

st.subheader("Dataset Preview")

st.dataframe(df.head())

st.divider()

st.subheader("Available Features")

st.write(df.columns.tolist())

st.divider()

# =====================================================
# STEP 1
# Select Predictor Variables
# =====================================================

st.header("Step 1 : Select Predictor Variables")

numeric_columns = df.select_dtypes(include=np.number).columns.tolist()

remove_columns = []

for col in ["Failure"]:

    if col in numeric_columns:
        remove_columns.append(col)

numeric_columns = [
    c for c in numeric_columns
    if c not in remove_columns
]

selected_features = st.multiselect(

    "Select Predictor Variables",

    numeric_columns,

    default=numeric_columns

)

target = st.selectbox(

    "Select Target Variable",

    df.columns,

    index=df.columns.get_loc("Failure")
    if "Failure" in df.columns
    else 0

)

if st.button("Run Step 1"):

    X = df[selected_features]

    y = df[target]

    st.session_state["X"] = X

    st.session_state["y"] = y

    st.success("Predictor Variables Selected")

    st.subheader("Feature Matrix")

    st.dataframe(X.head())

    st.subheader("Target Variable")

    st.write(target)

    st.subheader("Class Distribution")

    st.dataframe(

        y.value_counts()

    )

st.divider()

# =====================================================
# STEP 2
# Label Encoding
# =====================================================

st.header("Step 2 : Encode Target Variable")

if "y" not in st.session_state:

    st.info("Please complete Step 1.")

else:

    if st.button("Run Step 2"):

        encoder = LabelEncoder()

        y_encoded = encoder.fit_transform(
            st.session_state["y"]
        )

        st.session_state["encoder"] = encoder
        st.session_state["y_encoded"] = y_encoded

        mapping = pd.DataFrame({

            "Class":

                encoder.classes_,

            "Encoded Value":

                range(len(encoder.classes_))

        })

        st.success("Encoding Completed")

        st.subheader("Encoding")

        st.dataframe(mapping)

st.divider()

# =====================================================
# STEP 3
# Cross validation
# =====================================================
st.header("Step 3 : 5-Fold Cross Validation")

if "y_encoded" not in st.session_state:

    st.info("Please complete Step 2.")

else:

    if st.button("Run Step 3"):

        X = st.session_state["X"]
        y = st.session_state["y_encoded"]

        model = LogisticRegression(
            random_state=42,
            max_iter=1000
        )

        kf = KFold(
            n_splits=5,
            shuffle=True,
            random_state=42
        )

        scores = cross_val_score(
            model,
            X,
            y,
            cv=kf,
            scoring="accuracy"
        )

        st.session_state["cv_scores"] = scores
        st.session_state["kf"] = kf

        st.success("5-Fold Cross Validation Completed")

        cv_results = pd.DataFrame({
            "Fold": [1, 2, 3, 4, 5],
            "Accuracy": scores
        })

        st.subheader("Cross Validation Results")

        st.dataframe(cv_results)

        c1, c2, c3 = st.columns(3)

        with c1:
            st.metric("Number of Folds", 5)

        with c2:
            st.metric(
                "Average Accuracy",
                f"{scores.mean():.4f}"
            )

        with c3:
            st.metric(
                "Standard Deviation",
                f"{scores.std():.4f}"
            )

        fig, ax = plt.subplots(figsize=(7,4))

        ax.plot(
            cv_results["Fold"],
            cv_results["Accuracy"],
            marker="o",
            linewidth=2
        )

        ax.set_xlabel("Fold")

        ax.set_ylabel("Accuracy")

        ax.set_title("5-Fold Cross Validation Accuracy")

        ax.set_ylim(0, 1)

        ax.grid(True)

        st.pyplot(fig)


# =====================================================
# STEP 4
# Train Logistic Regression Model
# =====================================================

st.header("Step 4 : Train Logistic Regression Model")

if "cv_scores" not in st.session_state:

    st.info("Please complete Step 3.")

else:

    if st.button("Run Step 4"):

        model = LogisticRegression(
            random_state=42,
            max_iter=1000
        )

        X = st.session_state["X"]
        y = st.session_state["y_encoded"]

        model.fit(X, y)

        st.session_state["model"] = model

        st.success("Model Trained Successfully")

        st.metric(
            "Number of Features",
            len(selected_features)
        )

        st.subheader("Model Intercept")

        st.write(model.intercept_[0])

        coef_df = pd.DataFrame({

            "Feature": selected_features,

            "Coefficient": model.coef_[0]

        })

        st.session_state["coef_df"] = coef_df

        st.subheader("Regression Coefficients")

        st.dataframe(coef_df)

st.divider()

# =====================================================
# STEP 5
# Predict Testing Dataset
# =====================================================

st.header("Step 5 : Cross Validation Predictions")

if "model" not in st.session_state:

    st.info("Please complete Step 4.")

else:

    if st.button("Run Step 5"):

        model = st.session_state["model"]

        X = st.session_state["X"]
        y = st.session_state["y_encoded"]

        kf = st.session_state["kf"]

        y_pred = cross_val_predict(
            model,
            X,
            y,
            cv=kf
        )

        st.session_state["y_pred"] = y_pred

        st.session_state["y_pred"] = y_pred

        encoder = st.session_state["encoder"]

        actual = encoder.inverse_transform(y)

        predicted = encoder.inverse_transform(
            y_pred
        )

        comparison = pd.DataFrame({

            "Actual Status": actual,

            "Predicted Status": predicted

        })

        comparison["Correct Prediction"] = (

            comparison["Actual Status"]

            ==

            comparison["Predicted Status"]

        )

        st.session_state["comparison"] = comparison

        st.success("Prediction Completed")

        st.subheader("Actual vs Predicted")

        st.dataframe(
            comparison.head(20)
        )

st.divider()

# =====================================================
# STEP 6
# Predict New Telecom Tower
# =====================================================

st.header("Step 6 : Predict New Telecom Tower")

st.write("Enter values for a new telecom tower")

new_data = []

cols = st.columns(2)

for i, feature in enumerate(selected_features):

    with cols[i % 2]:

        value = st.number_input(

            feature,

            value=float(df[feature].mean())

        )

    new_data.append(value)

if "model" not in st.session_state:

    st.info("Please complete Step 4.")

else:

    if st.button("Run Step 6"):

        model = st.session_state["model"]

        encoder = st.session_state["encoder"]

        prediction = model.predict([new_data])

        probability = model.predict_proba([new_data])

        label = encoder.inverse_transform(prediction)[0]

        st.success("Prediction Completed")

        st.metric(

            "Predicted Status",

            label

        )

        prob_df = pd.DataFrame({

            "Class": encoder.classes_,

            "Probability": probability[0]

        })

        st.subheader("Prediction Probability")

        st.dataframe(prob_df)

# =====================================================
# STEP 7
# Evaluate Model
# =====================================================

st.header("Step 7 : Evaluate Classification Model")

if "y_pred" not in st.session_state:

    st.info("Please complete Step 5.")

else:

    if st.button("Run Step 7"):

        y = st.session_state["y_encoded"]
        y_pred = st.session_state["y_pred"]

        accuracy = accuracy_score(
            y,
            y_pred
        )

        cm = confusion_matrix(
            y,
            y_pred
        )

        report = classification_report(
            y,
            y_pred,
            target_names=st.session_state["encoder"].classes_,
            output_dict=True
        )

        st.session_state["accuracy"] = accuracy
        st.session_state["cm"] = cm

        st.success("Model Evaluation Completed")

        c1, c2 = st.columns(2)

        with c1:
            st.metric(
                "Accuracy",
                f"{accuracy:.4f}"
            )

        with c2:
            st.metric(
                "Correct Predictions",
                int(cm.trace())
            )

        st.subheader("Classification Report")

        report_df = pd.DataFrame(report).transpose()

        st.dataframe(
            report_df.round(3)
        )

st.divider()

# =====================================================
# STEP 8
# Confusion Matrix
# =====================================================

st.header("Step 8 : Display Confusion Matrix")

if "cm" not in st.session_state:

    st.info("Please complete Step 7.")

else:

    if st.button("Run Step 8"):

        cm = st.session_state["cm"]

        fig, ax = plt.subplots(figsize=(6,5))

        im = ax.imshow(
            cm,
            cmap="Blues"
        )

        plt.colorbar(im)

        classes = st.session_state["encoder"].classes_

        ax.set_xticks(np.arange(len(classes)))
        ax.set_yticks(np.arange(len(classes)))

        ax.set_xticklabels(classes)
        ax.set_yticklabels(classes)

        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")

        ax.set_title("Confusion Matrix")

        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(
                    j,
                    i,
                    cm[i,j],
                    ha="center",
                    va="center",
                    fontsize=12
                )

        st.pyplot(fig)

st.divider()

# =====================================================
# STEP 9
# Feature Importance
# =====================================================

st.header("Step 9 : Regression Coefficient Analysis")

if "coef_df" not in st.session_state:

    st.info("Please complete Step 4.")

else:

    if st.button("Run Step 9"):

        coef_df = st.session_state["coef_df"].copy()

        coef_df["Absolute"] = coef_df["Coefficient"].abs()

        coef_df = coef_df.sort_values(
            "Absolute",
            ascending=False
        )

        st.subheader("Feature Importance")

        st.dataframe(
            coef_df
        )

        fig, ax = plt.subplots(figsize=(10,5))

        ax.bar(
            coef_df["Feature"],
            coef_df["Coefficient"]
        )

        ax.set_xlabel("Features")
        ax.set_ylabel("Coefficient")
        ax.set_title("Influence of Engineering Parameters")

        plt.xticks(rotation=45)

        st.pyplot(fig)

st.divider()

# =====================================================
# FINAL RESULTS
# =====================================================

st.header("Final Results")

if "accuracy" in st.session_state:

    st.success("Experiment Completed Successfully")

    c1,c2,c3 = st.columns(3)

    with c1:
        st.metric(
            "Samples",
            len(st.session_state["X"])
        )

    with c2:
        st.metric(
            "Features",
            len(selected_features)
        )

    with c3:
        st.metric(
            "Average CV Accuracy",
            f"{np.mean(st.session_state['cv_scores']):.4f}"
        )

    st.subheader("Prediction Sample")

    st.dataframe(
        st.session_state["comparison"].head(10)
    )

    csv = st.session_state["comparison"].to_csv(index=False)

    st.download_button(
        "Download Prediction Results",
        csv,
        "prediction_results.csv",
        "text/csv"
    )