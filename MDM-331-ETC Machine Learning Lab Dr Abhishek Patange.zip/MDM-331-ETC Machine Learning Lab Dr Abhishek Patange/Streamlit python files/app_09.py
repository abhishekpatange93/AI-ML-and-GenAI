# app.py
import streamlit as st
import pandas as pd
import ollama

st.set_page_config(page_title="AI Investigation Chatbot", layout="wide")

st.title("Experiment 9: AI-Assisted ML using Local LLMs (Ollama) and Chatbot 🤖")
st.caption("Step-by-step investigations using Ollama")

# -----------------------------
# CSV Upload
# -----------------------------
uploaded_file = st.file_uploader("Step 1: Upload CSV Dataset", type=["csv"])

if uploaded_file is None:
    st.info("Please upload a CSV file to continue.")
    st.stop()

df = pd.read_csv(uploaded_file)

st.success("Dataset Loaded Successfully")

with st.expander("Dataset Preview"):
    st.dataframe(df.head())
    st.write("Rows:", df.shape[0])
    st.write("Columns:", df.shape[1])

columns = ", ".join(df.columns)

# -----------------------------
# Helper
# -----------------------------
def ask_llm(prompt):
    response = ollama.chat(
        model="llama3.2",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )
    return response["message"]["content"]

# -----------------------------
# Investigation Prompts
# -----------------------------
investigations = [

# ------------------------------------------------
# Investigation 1
# ------------------------------------------------

{
"title":"1. Describe Dataset Features",
"prompt":f"""
I have a dataset with these columns:

{columns}

Describe the purpose of every feature in simple engineering language.
""",
"result":"AI description of every dataset feature."
},

{
"title":"2. Identify Machine Learning Problems",
"prompt":"""
Based on this dataset identify suitable:

1. Regression

2. Classification

3. Clustering

4. Dimensionality Reduction

Explain why each is appropriate.
""",
"result":"Suitable ML tasks with justification."
},

{
"title":"3. Recommend Complete ML Workflow",
"prompt":"""
Suggest a complete Machine Learning workflow.

Include

- Data preprocessing
- Feature scaling
- Feature selection
- Model selection
- Model evaluation
- Engineering applications
""",
"result":"Complete ML pipeline."
},

{
"title":"4. Interpretation Questions",
"prompt":"""
Answer these:

1. How did you describe the Failure attribute?

2. Which ML applications are recommended?

3. Does the workflow match a traditional ML workflow?

4. Advantages of AI-assisted dataset analysis?

5. Should engineers rely only on AI? Justify.
""",
"result":"Answers for Investigation Sheet."
},

# ------------------------------------------------
# Investigation 2
# ------------------------------------------------

{
"title":"5. Recommend ML Algorithm",
"prompt":"""
The target variable is 'Failure'.

Recommend the best Machine Learning algorithm and explain why.
""",
"result":"Recommended algorithm."
},

{
"title":"6. Generate Python Code",
"prompt":"""
Generate Scikit-Learn code.

Include

- Import libraries
- Load dataset
- Feature selection
- Train-test split
- Model training
- Prediction
- Accuracy calculation
""",
"result":"Complete ML code."
},

{
"title":"7. Explain Generated Code",
"prompt":"""
Explain every section of the generated code.

Assume I am a second-year engineering student.
""",
"result":"Step-by-step explanation."
},

{
"title":"8. Improve Model",
"prompt":"""
Suggest three ways to improve the model accuracy.

Explain why each improvement helps.
""",
"result":"Improvement suggestions."
},

{
"title":"9. Compare with Manual Implementation",
"prompt":"""
Compare AI-generated code with a manually written implementation.

Mention similarities and differences.
""",
"result":"Comparison."
},

{
"title":"10. Investigation Questions",
"prompt":"""
Answer:

1. Which algorithm was recommended?

2. Did AI-generated code closely match manual implementation?

3. Was the explanation clear?

4. Best improvement suggested?

5. Would you use AI-generated code directly in production? Justify.
""",
"result":"Answers for Investigation Sheet."
},

# ------------------------------------------------
# Investigation 3
# ------------------------------------------------

{
"title":"11. Explain Evaluation Metrics",
"prompt":"""
Interpret these results.

Accuracy = 91.7%

Precision = 0.90

Recall = 0.93

F1 Score = 0.91

Explain in simple engineering language.
""",
"result":"Explanation of metrics."
},

{
"title":"12. Interpret Confusion Matrix",
"prompt":"""
Interpret this confusion matrix.

Predicted

Fail      Not Fail

Actual Fail      28      2

Actual Not Fail  3      27

Explain model performance.
""",
"result":"Confusion Matrix interpretation."
},

{
"title":"13. Generate Engineering Report",
"prompt":"""
Prepare a professional engineering report.

Include

Objective

Model Performance

Engineering Interpretation

Recommendations

Conclusion
""",
"result":"Engineering report."
},

{
"title":"14. Explain for Non-Technical Audience",
"prompt":"""
Explain these ML results to a telecom maintenance engineer.

Avoid AI and Machine Learning jargon.
""",
"result":"Simple explanation."
},

{
"title":"15. Engineering Recommendations",
"prompt":"""
Answer:

1. Should the model be deployed?

2. What improvements are recommended?

3. What are the limitations?

Answer like a telecom engineer.
""",
"result":"Engineering recommendations."
},

{
"title":"16. Final Reflection",
"prompt":"""
Answer:

1. Were evaluation metrics explained correctly?

2. Was the confusion matrix interpreted correctly?

3. Was the engineering report meaningful?

4. Was the explanation suitable for non-technical users?

5. Would you use an LLM in future ML projects?

6. What are the advantages?

7. What are the limitations?

8. Write a brief conclusion summarizing the experiment.
""",
"result":"Final investigation answers and conclusion."
}

]

# -----------------------------
# Investigation UI
# -----------------------------
st.header("Investigations")

if "current" not in st.session_state:
    st.session_state.current = 0

current = st.session_state.current

investigation = investigations[current]

st.subheader(investigation["title"])

st.write("### Expected Result")
st.info(investigation["result"])

st.write("### Prompt")

edited_prompt = st.text_area(
    "You can modify the prompt before running",
    value=investigation["prompt"],
    height=250,
    key=f"prompt_{current}"
)


if st.button("Run Investigation"):

    with st.spinner("Thinking..."):

        prompt = f"""

Dataset Columns

{columns}

Dataset Sample

{df.head(5).to_string()}

--------------------------------

{edited_prompt}

"""

        answer = ask_llm(prompt)

    st.success("Completed")

    st.markdown(answer)

col1,col2 = st.columns(2)

with col1:
    if current > 0:
        if st.button("⬅ Previous"):
            st.session_state.current -= 1
            st.rerun()

with col2:
    if current < len(investigations)-1:
        if st.button("Next ➜"):
            st.session_state.current += 1
            st.rerun()

st.divider()

st.header("💬 Chat with Dataset")

if "messages" not in st.session_state:
    st.session_state.messages=[]

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

question=st.chat_input("Ask anything about the dataset...")

if question:

    st.session_state.messages.append(
        {
            "role":"user",
            "content":question
        }
    )

    with st.chat_message("user"):
        st.markdown(question)

    dataset_context=f"""

Dataset Columns

{columns}

Dataset Sample

{df.head(10).to_string()}

Answer the user's question based on this dataset.

Question:

{question}

"""

    answer=ask_llm(dataset_context)

    with st.chat_message("assistant"):
        st.markdown(answer)

    st.session_state.messages.append(
        {
            "role":"assistant",
            "content":answer
        }
    )